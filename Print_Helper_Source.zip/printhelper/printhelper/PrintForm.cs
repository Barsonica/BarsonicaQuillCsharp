﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Printing;
using System.IO;
using System.Windows.Documents;
using System.Windows.Markup;


namespace printhelper
{
    /// <summary>
    /// PrintForm() General Purpose RTF printer 09-28-2016 ver 1.0.0.3
    /// </summary>
    /// Uses: RichTextBoxPrintHelper.cs by Mrojas - http://blogs.artinsoft.net/mrojas/archive/2009/07/10/printing-richtextbox-contents-in-c.aspx
    /// and based on work of:  Martin Muller in http://msdn.microsoft.com/en-us/library/ms996492.aspx
    /// Author: Howard C. Williams
    /// To Use: add PrintForm.cs and RichTextBoxPrintHelper.cs to project, change namespace to match project namespace
    /// 
    /// Revisions:  09-28-2016 Added Header and Page number support, Preview Dialog now centered in parent window

    public partial class PrintForm : Form
    {
        public PrintForm()
        {
            InitializeComponent();
   
        }
        // Overload 1
        public PrintForm(string _Document)
        {
            InitializeComponent();
            document = _Document;
        }

        // RTF to print
        public string Document
        {
            get
            {
                return document;
            }
            set
            {
                document = value;
            }
        }

      
        // Returns Dialog Printer Settings
        public System.Drawing.Printing.PrinterSettings PrSettings
        {
            get
            {
                return printDocument1.PrinterSettings;
            }
            set
            {
            }

        }
        // Sets and Returns Dialog Page Settings
        // 06-15-2016 Added Set Option to Page Defaults
        // Note these are in one-hundreths of an inch
        public System.Drawing.Printing.PageSettings PgSettings
        {
            get
            {
                return printDocument1.DefaultPageSettings;
            }
            set
            {
                leftmargin = value.Margins.Left;
                rightmargin = value.Margins.Right;
                topmargin = value.Margins.Top;
                bottommargin = value.Margins.Bottom;
                landscapemode = value.Landscape;
                printDocument1.DefaultPageSettings.Margins.Left = leftmargin;
                printDocument1.DefaultPageSettings.Margins.Right = rightmargin;
                printDocument1.DefaultPageSettings.Margins.Top = topmargin;
                printDocument1.DefaultPageSettings.Margins.Bottom = bottommargin;
                printDocument1.DefaultPageSettings.Landscape = landscapemode;
            }
        }
        // True if an exception occurred
        public bool error
        {
            get
            {
                return this.ErrorFlag;
            }
            set
            {
            }
        }
        // Internal Error Message
        public string errormessage
        {
            get
            {
                return this.ErrorMessage;
            }
            set
            {
            }
        }

        // Contains Error Info
        public Exception printexception
        {
            get
            {
                return this.PrintException;
            }
            set
            {
            }
        }
        // Title For Window
        public string windowtitle
        {
            get
            {
                return this.windowtitle;
            }
            set
            {
                this.WindowTitle = value;
            }
        }
        // Header Font
        public Font headerfont
        {
            get
            {
                return HeaderFont;
            }
            set
            {
                HeaderFont = value;
            }
            
        }
        // Header String
        public string headerstring
        {
            get
            {
                return HeaderString;
            }
            set
            {
                HeaderString = value;
            }
        }
        // Add a header
        public bool addheader
        {
            get
            {
                return AddHeader;
            }
            set
            {
                AddHeader = value;
            }
        }
        // Number Pages
        public bool numberpages
        {
            get
            {
                return headerincludepagenumber;
            }
            set
            {
                headerincludepagenumber  = value;
            }
        }


        // ERROR HANDLING
        // Note: helper extension doesn't currently return any error flags so this is unused
        private bool ErrorFlag = false;
        private Exception PrintException = null;
        private string ErrorMessage = String.Empty;
        private string document = String.Empty;

        // PAGE SETTINGS
        private int leftmargin;
        private int rightmargin;
        private int topmargin;
        private int bottommargin;
        private bool landscapemode = false;
        private Font HeaderFont = new Font("Arial", 10);  // default header font
        private string HeaderString = string.Empty;
        private bool headerincludepagenumber = false;
        private bool AddHeader = false;
      
        private string WindowTitle = "Ready to Print"; // default
      
        
        // Page Setup 
		private void btnPageSetup_Click(object sender, System.EventArgs e)
		{
			pageSetupDialog1.PageSettings = new System.Drawing.Printing.PageSettings();
            pageSetupDialog1.PrinterSettings = new System.Drawing.Printing.PrinterSettings();
            pageSetupDialog1.PageSettings = printDocument1.DefaultPageSettings;
            pageSetupDialog1.PrinterSettings = printDocument1.PrinterSettings;

            if (pageSetupDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument1.DefaultPageSettings = pageSetupDialog1.PageSettings;
                printDocument1.PrinterSettings = pageSetupDialog1.PrinterSettings;
            }
            ShowPrinterName();
		}
        // Preview Method
		private void btnPrintPreview_Click(object sender, System.EventArgs e)
		{
            rtbBuffer.Rtf = document;
            rtbBuffer.Preview(printDocument1.DefaultPageSettings, printDocument1.PrinterSettings, ref PrintException);
            if (PrintException != null)
            {
                ErrorFlag = true;
            }
            else
            {
                ErrorFlag = false;
            }
            
		}
        // Print Method
        private void btnPrint_Click(object sender, System.EventArgs e)
        {
            // 09-23-2016 Transfer Header Settings
            RichTextBoxPrintHelper.headeron = AddHeader;
            RichTextBoxPrintHelper.pagenumberson = headerincludepagenumber;
            RichTextBoxPrintHelper.headerfont = HeaderFont;
            RichTextBoxPrintHelper.headerstring = HeaderString;
            
            // 09-02-14: Added Page and Printer fields to Helper
            rtbBuffer.Rtf = document;
            rtbBuffer.Print(printDocument1.DefaultPageSettings,printDocument1.PrinterSettings,ref PrintException);
            if (PrintException != null)
            {
                ErrorFlag = true;
            }
            else
            {
                ErrorFlag = false;
            }

            this.Close();
                		
        }
        // Quit    
        private void btnQuit_Click(object sender, EventArgs e)
        {
            ErrorFlag = false;
            this.Close();
        }
        // Form Load
        private void MainForm_Load(object sender, EventArgs e)
        {
            this.ErrorFlag = false;
            rtbBuffer.Rtf = document;
            this.Text = WindowTitle;
            ShowPrinterName();
        }
        // Displays Default printer
        private void ShowPrinterName()
        {
            this.lblPrintForm1.Text = "Printer ->  "+printDocument1.PrinterSettings.PrinterName;
        }
        // CHOOSE PRINTER FROM LIST
        private void lblPrintForm1_Click(object sender, EventArgs e)
        {
            lbPrintFormSelect.Items.Clear();
            foreach (string s in PrinterSettings.InstalledPrinters)
            {
                lbPrintFormSelect.Items.Add(s);
            }
            lbPrintFormSelect.Visible = true;

        }
        // LISTBOX HANDLER
        private void lbPrintFormSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            printDocument1.PrinterSettings.PrinterName = lbPrintFormSelect.Items[lbPrintFormSelect.SelectedIndex].ToString();
            lbPrintFormSelect.Visible = false;
            ShowPrinterName();
        }
        // Printer Settings Button
        private void button1_Click(object sender, EventArgs e)
        {
            if (printDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument1.PrinterSettings = printDialog1.PrinterSettings;
                ShowPrinterName();

            }
        }

       

   }
    
}
