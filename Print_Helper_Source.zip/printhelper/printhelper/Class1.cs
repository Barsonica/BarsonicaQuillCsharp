﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

// Version 1.0.0.1 09-28-2016
// Author: Howard C Williams
// To use: 1- copy printhelper.dll to your project folder, 2 - Add to project as an existing item (Browse), 3 - Add a Reference to the dll
//         in the project, and 4 - finally add "using printhelper;" to the .cs file of your project
//         Create a new instance of PrintTools (PrintTools pt = new PrintTools();)
//         Then use whichever overload you want -  Constructor #1: pt.GeneralPrintForm("My Title",richTextBox1.Rtf,ref MyException)
//         Constructor #2 adds option to set page margins and landscape
//         or portrait mode.  Constructor #3 adds option to print a header string you supply, with a font of your choice
//         to each page and to add automatic page numbering.   To capture exceptions, create a new Exception and pass it by
//         reference to the constructors

namespace printhelper
{
    public class PrintTools
    {
        /// <summary>
        /// Displays a Basic Print Form For RichText
        /// </summary>
        /// <param name="WindowTitle"></param>
        /// <param name="RichTextBoxContent"></param>
        /// <param name="ex"></param>
        public void GeneralPrintForm(string WindowTitle, string RichTextBoxContent, ref Exception ex)
        {
            PrintForm pf = new PrintForm();
            pf.Document = RichTextBoxContent;
            pf.windowtitle = WindowTitle;
            pf.printexception = ex;
            pf.ShowDialog();
            pf.Dispose();
        }
        // OVERLOAD 1 - INLCUDES PAGE SETTINGS
        // Rev: 09-10-2016
        public void GeneralPrintForm(string WindowTitle, string RichTextBoxContent, ref Exception ex, System.Drawing.Printing.PageSettings Ps)
        {
            PrintForm pf = new PrintForm();
            pf.Document = RichTextBoxContent;
            pf.windowtitle = WindowTitle;
            pf.printexception = ex;
            pf.PgSettings.Margins.Left = Ps.Margins.Left;
            pf.PgSettings.Margins.Right = Ps.Margins.Right;
            pf.PgSettings.Margins.Top = Ps.Margins.Top;
            pf.PgSettings.Margins.Bottom = Ps.Margins.Bottom;
            pf.PgSettings.Landscape = Ps.Landscape;
            pf.ShowDialog();
            pf.Dispose();
        }
        // OVELOAD 2 - INCLUDES HEADER SETTINGS
        // Rev: 09-23-2016
        public void GeneralPrintForm(string WindowTitle, string RichTextBoxContent, ref Exception ex, System.Drawing.Printing.PageSettings Ps,
            bool headeron, string headerstring, Font headerfont, bool pagenumberson)
        {
            PrintForm pf = new PrintForm();
            pf.Document = RichTextBoxContent;
            pf.windowtitle = WindowTitle;
            pf.printexception = ex;
            pf.PgSettings.Margins.Left = Ps.Margins.Left;
            pf.PgSettings.Margins.Right = Ps.Margins.Right;
            pf.PgSettings.Margins.Top = Ps.Margins.Top;
            pf.PgSettings.Margins.Bottom = Ps.Margins.Bottom;
            pf.PgSettings.Landscape = Ps.Landscape;
            pf.addheader = headeron;
            pf.headerstring = headerstring;
            pf.headerfont = headerfont;
            pf.numberpages = pagenumberson;
            pf.ShowDialog();
            pf.Dispose();
        }
    }
}
